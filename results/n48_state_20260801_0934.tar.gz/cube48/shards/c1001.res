1001 rc=0 count=0
