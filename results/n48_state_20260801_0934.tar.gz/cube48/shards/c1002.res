1002 rc=0 count=0
