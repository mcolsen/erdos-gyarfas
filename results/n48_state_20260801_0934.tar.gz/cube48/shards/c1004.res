1004 rc=0 count=0
