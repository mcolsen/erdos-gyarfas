1005 rc=0 count=0
