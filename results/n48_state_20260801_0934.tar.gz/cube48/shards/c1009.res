1009 rc=0 count=0
