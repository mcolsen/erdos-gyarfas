1010 rc=0 count=0
