1014 rc=0 count=0
