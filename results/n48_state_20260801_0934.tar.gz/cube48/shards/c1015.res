1015 rc=0 count=0
