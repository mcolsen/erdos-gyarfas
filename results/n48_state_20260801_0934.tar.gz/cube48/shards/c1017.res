1017 rc=0 count=0
