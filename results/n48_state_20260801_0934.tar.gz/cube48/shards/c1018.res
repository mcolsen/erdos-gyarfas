1018 rc=0 count=0
