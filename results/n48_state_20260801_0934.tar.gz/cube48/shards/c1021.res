1021 rc=0 count=0
