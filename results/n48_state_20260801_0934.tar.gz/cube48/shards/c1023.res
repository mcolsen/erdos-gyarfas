1023 rc=0 count=0
