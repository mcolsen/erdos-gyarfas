1026 rc=0 count=0
