1029 rc=0 count=0
