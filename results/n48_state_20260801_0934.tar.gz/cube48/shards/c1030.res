1030 rc=0 count=0
