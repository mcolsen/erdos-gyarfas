1033 rc=0 count=0
