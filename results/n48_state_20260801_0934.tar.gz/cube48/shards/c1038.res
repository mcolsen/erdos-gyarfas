1038 rc=0 count=0
