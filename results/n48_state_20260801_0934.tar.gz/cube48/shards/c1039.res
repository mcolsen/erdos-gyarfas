1039 rc=0 count=0
