1042 rc=0 count=0
