1043 rc=0 count=0
