1044 rc=0 count=0
