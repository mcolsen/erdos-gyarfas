1045 rc=0 count=0
