1046 rc=0 count=0
