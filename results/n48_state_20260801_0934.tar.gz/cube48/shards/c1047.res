1047 rc=0 count=0
