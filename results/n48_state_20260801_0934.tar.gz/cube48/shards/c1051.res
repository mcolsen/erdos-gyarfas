1051 rc=0 count=0
