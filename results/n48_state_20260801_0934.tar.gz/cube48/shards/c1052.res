1052 rc=0 count=0
