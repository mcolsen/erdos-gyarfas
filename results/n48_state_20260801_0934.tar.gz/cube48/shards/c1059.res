1059 rc=0 count=0
