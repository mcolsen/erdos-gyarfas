1061 rc=0 count=0
