1069 rc=0 count=0
