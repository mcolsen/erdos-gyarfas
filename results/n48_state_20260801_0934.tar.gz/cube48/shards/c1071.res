1071 rc=0 count=0
