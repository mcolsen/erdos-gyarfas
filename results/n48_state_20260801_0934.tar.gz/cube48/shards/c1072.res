1072 rc=0 count=0
