1076 rc=0 count=0
