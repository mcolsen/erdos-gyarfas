1079 rc=0 count=0
