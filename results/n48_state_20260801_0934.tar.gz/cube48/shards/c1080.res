1080 rc=0 count=0
