1081 rc=0 count=0
