1083 rc=0 count=0
