1087 rc=0 count=0
