1089 rc=0 count=0
