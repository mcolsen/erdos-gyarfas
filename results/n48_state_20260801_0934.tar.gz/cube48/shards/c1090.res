1090 rc=0 count=0
