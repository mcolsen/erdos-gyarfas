1096 rc=0 count=0
