1103 rc=0 count=0
