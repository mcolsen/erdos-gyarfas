1106 rc=0 count=0
