1109 rc=0 count=0
