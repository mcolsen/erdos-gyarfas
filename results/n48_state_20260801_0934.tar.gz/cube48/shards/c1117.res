1117 rc=0 count=0
