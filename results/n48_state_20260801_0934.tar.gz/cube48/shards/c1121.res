1121 rc=0 count=0
