1122 rc=0 count=0
