1129 rc=0 count=0
