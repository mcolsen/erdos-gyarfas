1130 rc=0 count=0
