1131 rc=0 count=0
