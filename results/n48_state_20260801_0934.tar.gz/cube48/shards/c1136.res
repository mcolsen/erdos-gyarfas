1136 rc=0 count=0
