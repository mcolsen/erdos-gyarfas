1137 rc=0 count=0
