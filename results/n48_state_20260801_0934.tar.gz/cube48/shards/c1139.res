1139 rc=0 count=0
