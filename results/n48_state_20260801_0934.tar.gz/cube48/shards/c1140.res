1140 rc=0 count=0
