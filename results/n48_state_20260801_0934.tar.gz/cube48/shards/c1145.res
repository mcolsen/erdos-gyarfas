1145 rc=0 count=0
