1148 rc=0 count=0
