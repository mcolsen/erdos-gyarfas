1156 rc=0 count=0
