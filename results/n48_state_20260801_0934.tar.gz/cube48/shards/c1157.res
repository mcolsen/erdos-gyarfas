1157 rc=0 count=0
