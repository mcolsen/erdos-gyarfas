1158 rc=0 count=0
