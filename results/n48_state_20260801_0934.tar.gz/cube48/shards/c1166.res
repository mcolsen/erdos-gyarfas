1166 rc=0 count=0
