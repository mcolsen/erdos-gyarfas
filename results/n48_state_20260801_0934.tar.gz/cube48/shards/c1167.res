1167 rc=0 count=0
