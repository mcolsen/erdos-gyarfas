1172 rc=0 count=0
