1173 rc=0 count=0
