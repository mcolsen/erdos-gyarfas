1180 rc=0 count=0
