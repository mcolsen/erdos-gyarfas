1181 rc=0 count=0
