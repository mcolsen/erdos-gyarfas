1183 rc=0 count=0
