1186 rc=0 count=0
