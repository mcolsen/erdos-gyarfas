1189 rc=0 count=0
