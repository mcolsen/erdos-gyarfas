1194 rc=0 count=0
