1195 rc=0 count=0
