912 rc=0 count=0
