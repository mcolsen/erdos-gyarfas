916 rc=0 count=0
